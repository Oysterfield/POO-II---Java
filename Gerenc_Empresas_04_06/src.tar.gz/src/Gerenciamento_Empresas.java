/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */



/**
 *
 * @author cancian
 */
public class Gerenciamento_Empresas {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
