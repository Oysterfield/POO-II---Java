/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package ufsc.ctc.ine.ine5404.gerenciamento_empresas.model;

/**
 *
 * @author cancian
 */
public class Gerenciamento_Empresas {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
